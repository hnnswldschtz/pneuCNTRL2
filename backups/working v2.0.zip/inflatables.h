#include "PneuCNTRL.h"

struct Inflatable {
    int safety_Stop;
    int min_pressure;
    int max_pressure;
    int inflation_inertia;
    int deflation_inertia;
};

Inflatable Baguette={

    19000,
    Baguette.min_pressure = 15500;
    Baguette.max_pressure = 18750;
    Baguette.inflation_inertia = 20;
    Baguette.deflation_inertia = 10;
}
